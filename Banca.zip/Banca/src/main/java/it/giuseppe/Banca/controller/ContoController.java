package it.giuseppe.Banca.controller;


import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import it.giuseppe.Banca.model.Conto;
import it.giuseppe.Banca.model.Correntista;
import it.giuseppe.Banca.service.ContoService;
import it.giuseppe.Banca.service.CorrentistaService;

@Controller
public class ContoController {

	@Autowired
	private CorrentistaService correntistaService;
	
	@Autowired
	private ContoService contoService;
	
	@PostMapping("/insConto")
public String insertConto(@ModelAttribute("Conto") Conto conto, HttpServletRequest request) {
		long corr = Long.parseLong(request.getParameter("id"));
		Correntista correntista = correntistaService.getCorrentistaById(corr);
		Conto conto1 = new Conto();
		conto1.setCorrentista(correntista);
		conto1.setSaldo(conto.getSaldo());
		conto1.setNumeroConto(conto.getNumeroConto());
		
	    
		contoService.salvaConto(conto1);
		
		return "redirect:/";
	}
	
	@GetMapping("/formConto/{id}")
	public String formConto (@PathVariable(value = "id" )long id, Model model){
	
	Conto conto = new Conto();
	Correntista corr = correntistaService.getCorrentistaById(id);
    
     model.addAttribute("nome", corr.toString());
	model.addAttribute("conto", conto);
	model.addAttribute("id", id );
	
	return "insConto";
}
	
	@GetMapping ("/versamento/{id}")
	public String versamento(@PathVariable ( value = "id") long id , Model model) {
		
		Conto conto = contoService.getContoById(id);	
		
		model.addAttribute("conto" , conto);
		return "versamento";
		
		
	}
	
	
	
	@PostMapping("/salvaVersamento")
	public String salvaVersamento (@ModelAttribute("ContoCorrente")Conto conto, HttpServletRequest request)
	{
		
		
		double numero = Double.parseDouble(request.getParameter("numero"));
		
		double somma = conto.getSaldo() + numero;
		
		conto.setSaldo(somma);
	
		System.out.println(conto.getSaldo());
		
		contoService.salvaConto(conto);
		return "redirect:/";
		
		
	}
	
	@GetMapping ("/prelievo/{id}")
	public String prelievo(@PathVariable ( value = "id") long id , Model model) {
		
		Conto conto = contoService.getContoById(id);	
		
		model.addAttribute("conto" , conto);
	
		return "prelievo";
		
		
	}
	
	@PostMapping("/salvaPrelievo")
	public String salvaPrelievo (@ModelAttribute("ContoCorrente")Conto conto, HttpServletRequest request)
	{
		

		
		double numero = Double.parseDouble(request.getParameter("numero"));
		
		double sottrazione = conto.getSaldo() - numero;
		
		conto.setSaldo(sottrazione);
	
		System.out.println(conto.getSaldo());
		
		contoService.salvaConto(conto);
		return "redirect:/";
		
		
	}


}
