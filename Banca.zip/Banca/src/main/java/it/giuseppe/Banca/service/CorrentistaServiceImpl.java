package it.giuseppe.Banca.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.giuseppe.Banca.model.Correntista;
import it.giuseppe.Banca.repository.CorrentistaRepository;

@Service
public class CorrentistaServiceImpl implements CorrentistaService {

	@Autowired
	CorrentistaRepository correntistaRepository;
	
	@Override
	public List<Correntista> getAllCorrentisti() {
	
		return correntistaRepository.findAll();
	} 

	@Override
	public void salvaCorrentista(Correntista correntista) {
	
		this.correntistaRepository.save(correntista);
	}

	@Override
	public Correntista getCorrentistaById(long id) {
	       
		Optional <Correntista> corr = correntistaRepository.findById(id);
		Correntista correntista = null;
		correntista = corr.get();
		
	  
		
		return correntista;
	}

	@Override
	public void cancellaCorrentistaById(long id) {
		this.correntistaRepository.deleteById(id);
		
	}

}
