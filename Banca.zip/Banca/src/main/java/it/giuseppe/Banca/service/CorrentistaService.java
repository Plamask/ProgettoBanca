package it.giuseppe.Banca.service;

import java.util.List;

import org.springframework.stereotype.Service;

import it.giuseppe.Banca.model.Correntista;

@Service
public interface CorrentistaService {

	List<Correntista> getAllCorrentisti();
	void salvaCorrentista(Correntista correntista);
	Correntista getCorrentistaById(long id);
	void cancellaCorrentistaById(long id);
}
