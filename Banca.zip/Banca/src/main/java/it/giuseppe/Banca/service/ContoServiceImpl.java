package it.giuseppe.Banca.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.giuseppe.Banca.model.Conto;
import it.giuseppe.Banca.model.Correntista;
import it.giuseppe.Banca.repository.ContoRepository;

@Service
public class ContoServiceImpl implements ContoService {

	@Autowired
	ContoRepository contoRepository;
	
	@Override
	public List<Conto> getAllConti() {
	
		return contoRepository.findAll();
	}

	@Override
	public void salvaConto(Conto conto) {
	
		this.contoRepository.save(conto);
		
	}

	@Override
	public Conto getContoById(long id) {
		Optional <Conto> c = contoRepository.findById(id);
		Conto conto = null;
		conto = c.get();
		return conto;
		
	}

	@Override
	public void cancellaContoById(long id) {
	
		this.contoRepository.deleteById(id);
	}

	@Override
	public List<Conto> findAllContiByCorrentista(Correntista correntista) {
		
		return contoRepository.findAllContiByCorrentista(correntista);

	}

}
