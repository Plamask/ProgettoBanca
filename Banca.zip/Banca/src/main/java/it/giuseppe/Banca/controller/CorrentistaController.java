package it.giuseppe.Banca.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;


import it.giuseppe.Banca.model.Correntista;
import it.giuseppe.Banca.service.ContoService;
import it.giuseppe.Banca.service.CorrentistaService;

@Controller
public class CorrentistaController {

	@Autowired
	private CorrentistaService correntistaService;
	
	@Autowired
	private ContoService contoService;
	
	@GetMapping ("/formCorr")
	public String formCorr(Model model) { 
		Correntista corr = new Correntista();
		model.addAttribute("corr", corr);
		
	
		return "index";
	}
	
	@PostMapping("/insertCorr")
	public String insertCorr(@ModelAttribute("Correntista") Correntista correntista) {
		
		correntistaService.salvaCorrentista(correntista);
		 
		return "redirect:/";
	}
	
	@GetMapping("/")
	public String lista(Model model) {
		
		model.addAttribute("lista", correntistaService.getAllCorrentisti());
		
		return "home"; 
	}
	
	@GetMapping ("/listaConti/{id}")
	public String listaConti(@PathVariable ( value = "id") long id , Model model) {
		
		
		
		
		//ho creato una query di utente bancari così mi trova i conti solo di quella 
		//determinata persona
		model.addAttribute("correntista" ,contoService.findAllContiByCorrentista(correntistaService.getCorrentistaById(id)));
		
		return "lista_conti";
	
	
	}
	
	
}
