package it.giuseppe.Banca.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import it.giuseppe.Banca.model.Conto;
import it.giuseppe.Banca.model.Correntista;

@Repository
public interface ContoRepository extends JpaRepository<Conto, Long> {

	
	List<Conto> findAllContiByCorrentista(Correntista correntista);
}
