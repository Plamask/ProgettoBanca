package it.giuseppe.Banca.service;

import java.util.List;

import it.giuseppe.Banca.model.Conto;
import it.giuseppe.Banca.model.Correntista;

public interface ContoService {

	List<Conto> getAllConti();
	void salvaConto(Conto conto);
	Conto getContoById(long id);
	void cancellaContoById(long id);
	List<Conto> findAllContiByCorrentista(Correntista correntista);
}
