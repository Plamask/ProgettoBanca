package it.giuseppe.Banca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BancaApplicationTests {

	@Test
	void contextLoads() {
	}

}
